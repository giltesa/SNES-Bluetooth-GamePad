Breadboard-compatible breakout board for the BluePacket BP20422 module
Created by Wayne and Layne, LLC - Version 1.03 - Last modified 2011/04/05

All the design files are licensed Creative Commons Attribution-Share Alike 3.0.
This means you may copy, distribute, and display them (and any modifications or
"derivative works: you make) if you give credit to Wayne and Layne, LLC, by
linking back to http://wayneandlayne.com/, and you must also license any
modifications or derivative works under this exact same Creative Commons
Attribution-Share Alike 3.0 License.

